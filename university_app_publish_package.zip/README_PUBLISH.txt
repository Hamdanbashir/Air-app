Air University Classroom Management App — GitHub publishing

1. Put push_university_app.ps1 beside air_university_corrected_ground_first_floor.zip.
2. Install Git for Windows if it is not already installed.
3. Open PowerShell in the folder containing both files.
4. Run: powershell -ExecutionPolicy Bypass -File .\push_university_app.ps1
5. Sign in to GitHub if prompted, inspect the changed-file summary, and type PUSH to confirm.
6. Verify the commit at https://github.com/Hamdanbashir/university-app/commits/main

This script clones main, copies only the app's 11 release files, checks the staged diff,
and pushes only after your confirmation. It does not delete unrelated repository files.
