$ErrorActionPreference = 'Stop'
$repo = 'https://github.com/Hamdanbashir/university-app.git'
$zip = Join-Path $PSScriptRoot 'air_university_corrected_ground_first_floor.zip'
if (!(Test-Path $zip)) { throw "Missing app ZIP: $zip" }
if (!(Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git is not installed. Install Git for Windows, then rerun.' }
$work = Join-Path $env:TEMP ('air-university-deploy-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
try {
  Write-Host 'Cloning the current GitHub main branch...'
  git clone --branch main $repo $work
  if ($LASTEXITCODE -ne 0) { throw 'Clone failed. Check GitHub authentication and internet connectivity.' }
  $staging = Join-Path $env:TEMP ('air-university-build-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $staging | Out-Null
  try {
    Expand-Archive -LiteralPath $zip -DestinationPath $staging -Force
    $required = @('index.html','app.js','styles.css','data/timetable.js','data/teachers.js')
    foreach ($file in $required) { if (!(Test-Path (Join-Path $staging $file))) { throw "Missing required build file: $file" } }
    foreach ($file in @('index.html','app.js','styles.css','README.md')) { Copy-Item (Join-Path $staging $file) (Join-Path $work $file) -Force }
    foreach ($folder in @('data','assets')) {
      $target = Join-Path $work $folder
      if (!(Test-Path $target)) { New-Item -ItemType Directory -Path $target | Out-Null }
      Copy-Item (Join-Path $staging "$folder\*") $target -Recurse -Force
    }
    Push-Location $work
    try {
      git add index.html app.js styles.css README.md data assets
      if ($LASTEXITCODE -ne 0) { throw 'git add failed.' }
      git diff --cached --check
      if ($LASTEXITCODE -ne 0) { throw 'Whitespace validation failed.' }
      git diff --cached --stat
      $changes = git diff --cached --name-only
      if (!$changes) { Write-Host 'GitHub already matches this build. No changes to push.'; return }
      $confirmation = Read-Host 'Type PUSH to commit and upload these changes to main'
      if ($confirmation -cne 'PUSH') { Write-Host 'Cancelled. No changes uploaded.'; return }
      git commit -m 'Deploy corrected AUSOM classroom app and room-wise schedules'
      if ($LASTEXITCODE -ne 0) { throw 'Commit failed. Configure Git name/email and retry.' }
      git push origin main
      if ($LASTEXITCODE -ne 0) { throw 'Push failed. Check permissions and whether main changed.' }
      Write-Host 'Push completed successfully.' -ForegroundColor Green
      git rev-parse HEAD
    } finally { Pop-Location }
  } finally { Remove-Item $staging -Recurse -Force -ErrorAction SilentlyContinue }
} finally { Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue }
